name1=['.\dataset\Gaussian object\0.bmp'];
I=double(imread(name1));
[M,N]=size(I);
s=min(M,N);
I=imresize(I,[s,s]);
radio=1/4;
I=imresize(I,radio);
phase=zeros(s,s);
phase((1/2-1/2*radio)*s:(1/2+1/2*radio)*s-1,(1/2-1/2*radio)*s:(1/2+1/2*radio)*s-1)=I;


deltax=1.85*10^-6;      %pixel size
lamda=632.8*10^-9;      %wavelength
z=900*10^-6;            %propagation distance
deltaz=50*10^-6;        %distance interval
f=exp(1i*(phase)/255*pi);   %object wavefront


%%The diffraction image 1
D1=diff_fun(f,lamda,z,deltax);
I1=D1.*conj(D1);

%%The diffraction image 2
D2=diff_fun(f,lamda,z+deltaz,deltax);
I2=D2.*conj(D2);

%%The diffraction image 3
D3=diff_fun(f,lamda,z+2*deltaz,deltax);
I3=D3.*conj(D3);

%%The diffraction image 4
D4=diff_fun(f,lamda,z+3*deltaz,deltax);
I4=D4.*conj(D4);

%%The diffraction image 5
D5=diff_fun(f,lamda,z+4*deltaz,deltax);
I5=D5.*conj(D5);

%%The diffraction image 6
D6=diff_fun(f,lamda,z+5*deltaz,deltax);
I6=D6.*conj(D6);

subplot(3,2,1), imshow(I1,[]);
subplot(3,2,2), imshow(I2,[]);
subplot(3,2,3), imshow(I3,[]);
subplot(3,2,4), imshow(I4,[]);
subplot(3,2,5), imshow(I5,[]);
subplot(3,2,6), imshow(I6,[]);

