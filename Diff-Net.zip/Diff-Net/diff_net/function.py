from ops1 import *
import argparse
import random
import os
import math
import tensorflow as tf
import numpy as np
import glob
import cv2
from numpy.ma import exp

#初始化参数
parser = argparse.ArgumentParser(description='')
parser.add_argument("--batch_size", type=int, default=3, help="batch_size.")  # 训练中每过多少step保存模型(可训练参数)
args = parser.parse_args()

def get_image(train_image, train_lable2, train_lable3, train_lable4, train_lable5, train_lable6, batch_size, quzhen, pic_weight, pic_hight):
    image_batch = []
    label2_batch = []
    label3_batch = []
    label4_batch = []
    label5_batch = []
    label6_batch = []
    for i in range(batch_size):
        num = i+quzhen*3
        x_line_content = train_image[num]  # 获取一张x域图片路径与名称
        y2_line_content = train_lable2[num]  # 获取一张y域图片路径与名称
        y3_line_content = train_lable3[num]  # 获取一张y域图片路径与名称
        y4_line_content = train_lable4[num]  # 获取一张y域图片路径与名称
        y5_line_content = train_lable5[num]  # 获取一张y域图片路径与名称
        y6_line_content = train_lable6[num]  # 获取一张y域图片路径与名称
        x_image = cv2.imread(x_line_content, 0)  # 读取一张x域的图片cv2.imread
        y2_image = cv2.imread(y2_line_content, 0)  # 读取一张y域的图片
        y3_image = cv2.imread(y3_line_content, 0)  # 读取一张y域的图片
        y4_image = cv2.imread(y4_line_content, 0)  # 读取一张y域的图片
        y5_image = cv2.imread(y5_line_content, 0)  # 读取一张y域的图片
        y6_image = cv2.imread(y6_line_content, 0)  # 读取一张y域的图片
        #y_image = np.loadtxt(y_line_content, delimiter=',')
        img_Z_f = x_image.astype("float32")
        phase2_f = y2_image.astype("float32")
        phase3_f = y3_image.astype("float32")
        phase4_f = y4_image.astype("float32")
        phase5_f = y5_image.astype("float32")
        phase6_f = y6_image.astype("float32")
        img_Z = img_Z_f /255
        phase2 = phase2_f / 255
        phase3 = phase3_f / 255
        phase4 = phase4_f / 255
        phase5 = phase5_f / 255
        phase6 = phase6_f / 255
        image_batch.append(img_Z)
        label2_batch.append(phase2)
        label3_batch.append(phase3)
        label4_batch.append(phase4)
        label5_batch.append(phase5)
        label6_batch.append(phase6)
    y_image = np.reshape(image_batch, (batch_size,pic_weight, pic_hight))
    y_label2 = np.reshape(label2_batch, (batch_size,pic_weight, pic_hight))
    y_label3 = np.reshape(label3_batch, (batch_size,pic_weight, pic_hight))
    y_label4 = np.reshape(label4_batch, (batch_size,pic_weight, pic_hight))
    y_label5 = np.reshape(label5_batch, (batch_size,pic_weight, pic_hight))
    y_label6 = np.reshape(label6_batch, (batch_size,pic_weight, pic_hight))
    out_image = np.zeros((batch_size, pic_weight, pic_hight, 5), dtype=float)
    out_image[:, :, :, 0] = y_image
    out_image[:, :, :, 1] = y_image
    out_image[:, :, :, 2] = y_image
    out_image[:, :, :, 3] = y_image
    out_image[:, :, :, 4] = y_image
    out_label = np.zeros((batch_size, pic_weight, pic_hight, 5), dtype=float)
    out_label[:, :, :, 0] = y_label2
    out_label[:, :, :, 1] = y_label3
    out_label[:, :, :, 2] = y_label4
    out_label[:, :, :, 3] = y_label5
    out_label[:, :, :, 4] = y_label6
    return out_image, out_label

#获取图片所在文件夹中的图片列表
def make_train_data_list(x_data_path, y2_data_path, y3_data_path, y4_data_path, y5_data_path, y6_data_path):  # make_train_data_list函数得到训练中的x域和y域的图像路径名称列表
    x_input_images_raw = glob.glob(os.path.join(x_data_path, "*"))  # 读取全部的x域图像路径名称列表
    y2_input_images_raw = glob.glob(os.path.join(y2_data_path, "*"))  # 读取全部的y域图像路径名称列表
    y3_input_images_raw = glob.glob(os.path.join(y3_data_path, "*"))  # 读取全部的y域图像路径名称列表
    y4_input_images_raw = glob.glob(os.path.join(y4_data_path, "*"))  # 读取全部的y域图像路径名称列表
    y5_input_images_raw = glob.glob(os.path.join(y5_data_path, "*"))  # 读取全部的y域图像路径名称列表
    y6_input_images_raw = glob.glob(os.path.join(y6_data_path, "*"))  # 读取全部的y域图像路径名称列表
    return x_input_images_raw, y2_input_images_raw, y3_input_images_raw, y4_input_images_raw, y5_input_images_raw, y6_input_images_raw


#打乱图像列表
def add_train_list(x_input_image_raw, y2_input_image_raw, y3_input_image_raw, y4_input_image_raw, y5_input_image_raw, y6_input_image_raw):
    if len(x_input_image_raw) == len(y2_input_image_raw):
        randnum = random.randint(0, 100)
        random.seed(randnum)
        random.shuffle(x_input_image_raw)
        random.seed(randnum)
        random.shuffle(y2_input_image_raw)
        random.seed(randnum)
        random.shuffle(y3_input_image_raw)
        random.seed(randnum)
        random.shuffle(y4_input_image_raw)
        random.seed(randnum)
        random.shuffle(y5_input_image_raw)
        random.seed(randnum)
        random.shuffle(y6_input_image_raw)
        return x_input_image_raw, y2_input_image_raw, y3_input_image_raw, y4_input_image_raw, y5_input_image_raw, y6_input_image_raw


#定义loss函数
def l1_loss(src, dst):  # 定义l1_loss
    return tf.reduce_mean(tf.abs(src - dst))


#定义loss函数
def l2_loss(src, dst):  # 定义l1_loss
    return tf.reduce_mean((src-dst)**2)


#定义loss函数
def ssim_loss(src, dst):  # 定义l1_loss
    return 1 - tf.reduce_mean(tf.image.ssim(src, dst, max_val = 1))

def rmse_loss(src, dst):
    return tf.sqrt(tf.reduce_mean(tf.square(src - dst)))


#定义菲弥尔衍射因子
def fme(N, deltax, deltaz, g, z):
    pi = math.pi
    w = 632.8 * 1e-9
    deltaf = 1 / N / deltax;
    rr = np.linspace(1, N, N);
    cc = np.linspace(1, N, N);
    C, R = np.meshgrid(cc, rr)
    pl = exp(-2 * 1j * pi * (z + g * deltaz) * ((1 / w) ** 2 - ((R - N / 2 - 1) * deltaf) ** 2 - ((C - N / 2 - 1) * deltaf) ** 2) ** 0.5)
    return pl


#定义判别网络
def discriminator(x,reuse=False):
    with tf.variable_scope("discriminator") as scope:
        if reuse:
            scope.reuse_variables()
        d = tf.nn.leaky_relu(layer_norm(conv2d('d_h1', x, 10, 32, ksize=3, strides=1), name='d_Ln1'))
        d = tf.nn.leaky_relu(layer_norm(conv2d('d_h2', d, 32, 64, ksize=3, strides=1), name='d_Ln2'))
        d = tf.nn.leaky_relu(layer_norm(conv2d('d_h3', d, 64, 128, ksize=3, strides=1), name='d_Ln3'))
        d = tf.nn.leaky_relu(layer_norm(conv2d('d_h4', d, 128, 128, ksize=3, strides=1), name='d_Ln4'))
        d = tf.nn.leaky_relu(layer_norm(conv2d('d_h5', d, 128, 128, ksize=3, strides=1), name='d_Ln5'))
        d = tf.nn.leaky_relu(layer_norm(conv2d('d_h6', d, 128, 64, ksize=3, strides=1), name='d_Ln6'))
        d = tf.nn.leaky_relu(layer_norm(conv2d('d_h7', d, 64, 5, ksize=3, strides=1), name='d_Ln7'))
        return d


#定义网络
def generator(x, reuse=False):
    with tf.variable_scope("generator") as scope:
        if reuse:
            scope.reuse_variables()

            # 128*
        g0 =  tf.nn.leaky_relu(layer_norm(conv2d('g_h0', x, 5, 128, ksize=3, strides=2), name='g_Ln0'))
        # 64 * 64
        g1 = tf.nn.leaky_relu(layer_norm(conv2d('g_h1', g0, 128, 64, ksize=3, strides=2), name='g_Ln1'))
        # 32 * 32
        g2 = tf.nn.leaky_relu(layer_norm(conv2d('g_h2', g1, 64, 64, ksize=3, strides=2), name='g_Ln2'))
        # 16 * 16
        g3 = tf.nn.leaky_relu(layer_norm(conv2d('g_h3', g2, 64, 64, ksize=3, strides=2), name='g_Ln3'))
        # 8 * 8
        # g4 = tf.nn.leaky_relu(layer_norm(conv2d('g_h4', g3, 64, 64, ksize=3, strides=2), name='g_Ln4'))
        g4 = tf.nn.leaky_relu(layer_norm(conv2d('g_h4', g3, 64, 64, ksize=3, strides=2), name='g_Ln4'))
        # 4 * 4
        g5 = tf.nn.leaky_relu(layer_norm(conv2d('g_h5', g4, 64, 64, ksize=3, strides=2), name='g_Ln5'))
        # 2 * 2
        g6 = tf.nn.leaky_relu(layer_norm(conv2d('g_h6', g5, 64, 64, ksize=3, strides=2), name='g_Ln6'))
        # 1 * 1
        g20 = tf.nn.leaky_relu(layer_norm(conv2d('g_h20', g6, 64, 128, ksize=3, strides=2), name='g_Ln20'))
        # 2 * 2

        g_1 = tf.nn.leaky_relu(deconv2d('g_h7', g20, 128, 64, 2, batch_size=args.batch_size, strides=2))
        g_1_1 = tf.concat([g_1, g6], axis=3)
        g_2 = tf.nn.leaky_relu(deconv2d('g_h8', g_1_1, 128, 64, 4, batch_size=args.batch_size, strides=2))
        # # 4 * 4
        g_1_2 = tf.concat([g_2, g5], axis=3)
        g_3 = tf.nn.leaky_relu(deconv2d('g_h9', g_1_2, 128, 64, 8, batch_size=args.batch_size, strides=2))
        g_1_3 = tf.concat([g_3, g4], axis=3)
        g_4 = tf.nn.leaky_relu(deconv2d('g_h10', g_1_3, 128, 64, 16, batch_size=args.batch_size, strides=2))
        # g_4 = tf.nn.leaky_relu(deconv2d('g_h10', g4, 128, 64, 16, batch_size=self.batch_size, strides=2), name='g_Ln10')
        g_1_4 = tf.concat([g_4, g3], axis=3)
        g_5 = tf.nn.leaky_relu(deconv2d('g_h11', g_1_4, 128, 64, 32, batch_size=args.batch_size, strides=2))
        g_1_5 = tf.concat([g_5, g2], axis=3)
        g_6 = tf.nn.leaky_relu(deconv2d('g_h12', g_1_5, 128, 64, 64, batch_size=args.batch_size, strides=2))
        g_1_6 = tf.concat([g_6, g1], axis=3)
        g_7 = tf.nn.leaky_relu(deconv2d('g_h13', g_1_6, 128, 128, 128, batch_size=args.batch_size, strides=2))
        g_1_7 = tf.concat([g_7, g0], axis=3)
        out_t = tf.nn.leaky_relu(deconv2d('g_h14', g_1_7, 256, 5, 256, batch_size=args.batch_size, strides=2))
        out = reshapename('shape', out_t)

        # out = maxminNormalization(out_t, name='normal')

        # tf.summary.image('generator_image', out_t, max_outputs=6)
        return out


def rb(name, x, ch_out, reuse = False):
    with tf.variable_scope(name) as scope:
        if reuse:
            scope.reuse_variables()
        if i == 0:
            x1 = conv2d('r0', x,  ch_out, ch_out, ksize=3, strides=1)
        x1 = conv2d('r1', x + x1,  ch_out, ch_out, ksize=3, strides=1)
        x1 = conv2d('r2', x + x1,  ch_out, ch_out, ksize=3, strides=1)
        return x1

def rrcnn(name, x, ch_in, ch_out, reuse = False):
    with tf.variable_scope(name) as scope:
        if reuse:
            scope.reuse_variables()
        x = conv2d('rr1', x, ch_in, ch_out, ksize=1, strides=1)
        x1 = rb('rb1', x, ch_out)
        x2 = rb('rb2', x1, ch_out)
        return x + x2


def generator3(x, reuse=False):
    with tf.variable_scope("generator3") as scope:
        if reuse:
            scope.reuse_variables()

        g_1 = rrcnn('g_1', x, 5, 64)
        g_1_d1 = maxpool(g_1, 2, 2)
        g_2 = rrcnn('g_2', g_1_d1, 64, 128)
        g_2_d2 = maxpool(g_2, 2, 2)
        g_3 = rrcnn('g_3', g_2_d2, 128, 256)
        g_3_d3 = maxpool(g_3, 2, 2)
        g_4 = rrcnn('g_4', g_3_d3, 256, 512)
        g_4_d4 = maxpool(g_4, 2, 2)
        g_5 = rrcnn('g_5', g_4_d4, 512, 1024)

        g_6 = deconv2d('g_6', g_5, 1024, 512, 32, batch_size=args.batch_size, strides=2)
        g_6_c = tf.concat([g_6, g_4], axis=3)
        g_7 = rrcnn('g_7', g_6_c, 1024, 512)

        g_8 = deconv2d('g_8', g_7, 512, 256, 64, batch_size=args.batch_size, strides=2)
        g_8_c = tf.concat([g_8, g_3], axis=3)
        g_9 = rrcnn('g_9', g_8_c, 512, 256)

        g_10 = deconv2d('g_10', g_9, 256, 128, 128, batch_size=args.batch_size, strides=2)
        g_10_c = tf.concat([g_10, g_2], axis=3)
        g_11 = rrcnn('g_11', g_10_c, 256, 128)

        g_12 = deconv2d('g_12', g_11, 128, 64, 256, batch_size=args.batch_size, strides=2)
        g_12_c = tf.concat([g_12, g_1], axis=3)
        g_13 = rrcnn('g_13', g_12_c, 128, 64)

        g_14 = conv2d('g_14', g_13, 64, 5, ksize=1, strides=1)

        return  g_14



