The environment of this network is the Tensorflow1.8GPU version based on python3.6.
Run the main.py file, the program will use the trained weight parameters in the ckpt folder to predict the diffraction images of another 5 positions.
Data presented are pollen diffractograms taken at an initial distance of z = 1300μm.