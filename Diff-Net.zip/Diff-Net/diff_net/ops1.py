import tensorflow as tf
import tensorflow.contrib.slim as slim
import math


import pylab as py
import numpy as np
from scipy import misc, fftpack
from numpy.ma import exp,sin,cos

def maxpool(x, size, strides):
    return tf.nn.max_pool(x, ksize=[1, size, size, 1], strides=[1, strides, strides, 1], padding='SAME')

def batch_norm (x,epsilon=1e-5,decay=0.9,name = 'batch_norm'):
    with tf.variable_scope(name):
        return tf.contrib.layers.batch_norm (x, decay = decay,epsilon = epsilon,scale = True,training=True)

def layer_norm (x,trainable = True ,name='layer_norm'):
    with tf.variable_scope(name):
        return tf.contrib.layers.layer_norm(x, trainable=trainable)

def linear(name ,x,batch_size,size,stddev = 0.9,in_size = 64 ):
    with tf.variable_scope(name):
        w = tf.get_variable('w',shape=[batch_size,size,size,in_size],initializer=tf.random_normal_initializer(stddev=stddev))
        y = tf.reduce_sum(tf.nn.relu(tf.multiply(x,w)),reduction_indices=[1,2,3])
        return y


def conv2d(name, x,input_ksize, output_dim, strides = 1, ksize= 3, stddev=0.02):
    with tf.variable_scope(name):
        w = tf.get_variable('w', [ksize, ksize, input_ksize, output_dim],initializer=tf.random_normal_initializer(stddev=stddev))
        biases = tf.get_variable('biases', [output_dim], initializer=tf.constant_initializer(0.0))
        conv = tf.nn.conv2d(x, w, strides=[1,strides,strides,1], padding='SAME')
        #conv = tf.nn.bias_add(conv, biases)
        return conv

def reshapename(name, x):
    with tf.variable_scope(name):
        r = tf.reshape(tf.nn.leaky_relu(x), x.get_shape(), 'out')
        return r


def deconv2d(name, x, input_ksize,output_dim, output_size,batch_size, strides = 2, ksize = 3, stddev=0.02):
    with tf.variable_scope(name):
        w = tf.get_variable('w', [ksize, ksize, output_dim,input_ksize],initializer=tf.random_normal_initializer(stddev=stddev))
        conv = tf.nn.conv2d_transpose(x, w, output_shape=[batch_size, output_size, output_size, output_dim], strides=[1,strides,strides,1])
        biases = tf.get_variable('biases', [output_dim], initializer=tf.constant_initializer(0.0))
        conv = tf.reshape(tf.nn.bias_add(conv, biases),conv.get_shape(), 'out')
        return conv

def dropout(x, keep_prob,name = 'dropout'):
    with tf.variable_scope(name):
        return tf.nn.dropout(x,keep_prob,noise_shape=None,seed=None)

def fftshift(im, axis=-1, name='fftshift'):
    with tf.variable_scope(name):
        #if not hasattr(axis, '__iter__'):
            #axis = [axis]
        output = im
        for a in (0,1):
            split0, split1 = tf.split(output, 2, axis=a)
            output = tf.concat((split1, split0), axis=a)
        return output

def maxminNormalization(im, name = 'maxminNormalization'):
    with tf.variable_scope(name):
        #im = tf.cast(imi, dtype=tf.float32)
        max = tf.reduce_max(im)
        min = tf.reduce_min(im)
        #output = tf.divide(tf.subtract(im, min), tf.subtract(max, min))
        return tf.divide(tf.subtract(im, min), tf.subtract(max, min))

def tff(im, name='tff'):
    with tf.variable_scope(name):
        cs = tf.cast(tf.fill([10,256,256,1], 255), dtype=tf.float32)
        output = tf.multiply(cs, im)
        return output

def tffpi(im, name='tff'):
    with tf.variable_scope(name):
        pi = math.pi
        cs = tf.cast(tf.fill([10,256,256,1], pi), dtype=tf.float32)
        output = tf.multiply(cs, im)
        return output
#def fme(N, deltax, deltaz, g, z, name='fme'):
    #with tf.variable_scope(name):
        #pi = math.pi
        #w = 632.8 * 1e-9
        #deltaf = 1 / N / deltax;
        #rr = np.linspace(1, N, N);
        #cc = np.linspace(1, N, N);
        #C, R = np.meshgrid(cc, rr)
        #pl = exp(-2 * 1j * pi * (z + g * deltaz) * ((1 / w) ** 2 - ((R - N / 2 - 1) * deltaf) ** 2 - ((C - N / 2 - 1) * deltaf) ** 2) ** 0.5)
        #return pl

def show_all_variables():
    model_vars = tf.trainable_variables()

    slim.model_analyzer.analyze_vars(model_vars, print_info=True)