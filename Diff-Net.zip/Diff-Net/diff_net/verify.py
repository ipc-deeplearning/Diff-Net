from ops1 import *
#from changetime_min_energy import *
import matplotlib.pyplot as plt
import tensorflow as tf
import cv2
import os
import copy
# import math
import numpy as np
import random
import time
os.environ['CUDA_VISIBLE_DEVICES'] = "1"

def evalaute(number, num_20, batch_size = 10, pic_weight = 256, pic_hight = 256):
    image_batch = []
    filepath = r"H:/updata/dataset/pollen/1"
    for i in range(number):
        num = i
        i1 = np.loadtxt(filepath  + '/' + str(num+num_20) + '.csv', delimiter=',')
        img_Z = i1.astype("float64")
        img_Z_1 = img_Z / 255
        image_batch.append(img_Z_1)
    y_image = np.reshape(image_batch, (batch_size, pic_weight, pic_hight))
    real_out_image = np.zeros((batch_size, pic_weight, pic_hight, 5))
    real_out_image[:, :, :, 0] = y_image
    real_out_image[:, :, :, 1] = y_image
    real_out_image[:, :, :, 2] = y_image
    real_out_image[:, :, :, 3] = y_image
    real_out_image[:, :, :, 4] = y_image
    real_out_image = real_out_image.astype(np.float32)
    return real_out_image


graph_dir = "H:/updata/diff_net/ckpt/diff.ckpt1000-40000.meta"  # 235100-0.36 285500-0.3545
model_dir = "H:/updata/diff_net/ckpt/diff.ckpt1000-40000"  #

with tf.Session() as sess:
    new_saver = tf.train.import_meta_graph(graph_dir)
    new_saver.restore(sess, model_dir)
    graph = tf.get_default_graph()
    for j in range(0,1):
        prediction0 = evalaute(10,j*10)
        x = graph.get_tensor_by_name("g_x_img:0")
        y = graph.get_tensor_by_name("generator/shape/out:0")
        prediction2 = sess.run(y,{x:prediction0})
        t0 = time.time()
        for i in range(0, 10):
            for l in range(0, 5):
                t5 =time.time()


                prediction1 = prediction2[i, :, :, l] * 255
                np.savetxt('H:/updata/dataset/pollen' + '/' + str(l+2) + '/' + str(i+j*10) + '.csv', prediction1, delimiter=',')
                cv2.waitKey(0)
        t1 = time.time()
        print("time:", t1-t0)

    print("end")