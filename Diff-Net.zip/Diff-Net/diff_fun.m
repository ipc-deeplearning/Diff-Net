function [U] = diff(I,lamda,z,pixelsize)

[M,N]=size(I);
pixelnumx=N;
pixelnumy=M;
deltafx=1/M/pixelsize;
deltafy=1/N/pixelsize;
Lx=pixelnumx*pixelsize;
Ly=pixelnumy*pixelsize;
xarray=1:pixelnumx;
yarray=1:pixelnumy;
[xgrid,ygrid]=meshgrid(xarray,yarray);
prop=exp(2*1i*pi*z*((1/lamda)^2-((xgrid-pixelnumx/2-1).*deltafx).^2-((ygrid-pixelnumy/2-1).*deltafy).^2).^0.5);   
prop_fft = fftshift(fft2(fftshift(I)));
U = fftshift(ifft2(fftshift(prop_fft.*prop)));
end

